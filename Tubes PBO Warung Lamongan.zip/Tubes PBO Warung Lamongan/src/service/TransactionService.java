package service;

import model.Transaction;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TransactionService {
    private List<Transaction> transactions = new ArrayList<>();

    public void addTransaction(Transaction trx) {
        transactions.add(trx);
    }

    public List<Transaction> getTransactionsByDate(LocalDate date) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction t : transactions) {
            if (t.getTimestamp().toLocalDate().equals(date)) {
                result.add(t);
            }
        }
        return result;
    }

    public double getTotalSales(LocalDate date) {
        double total = 0;
        for (Transaction t : transactions) {
            if (t.getTimestamp().toLocalDate().equals(date)) {
                total += t.calculateTotal();
            }
        }
        return total;
    }
}
