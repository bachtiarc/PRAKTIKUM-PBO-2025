package service;

import model.MenuProduct;
import model.Transaction;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class TransactionDBHelper {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/cobaLamongan";
    private static final String USER = "root";
    private static final String PASS = "BDCikal15";

    // [FIX 2] Method yang sesuai dengan struktur tabel
    public static void saveToDatabase(String customer, Transaction trx) {
    String insertMain = "INSERT INTO transaksi_utama (customer_name, total_price, transaction_time) VALUES (?, ?, ?)";
    String insertDetail = "INSERT INTO transaksi_detail (id_transaksi, item_name, quantity, item_price, total_price) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
        conn.setAutoCommit(false); // penting agar bisa rollback kalau gagal di tengah
        
        try (
            PreparedStatement pstmtMain = conn.prepareStatement(insertMain, Statement.RETURN_GENERATED_KEYS);
            PreparedStatement pstmtDetail = conn.prepareStatement(insertDetail)
        ) {
            // Hitung total harga
            double totalHarga = trx.calculateTotal();

            // Step 1: Insert ke transaksi_utama
            pstmtMain.setString(1, customer);
            pstmtMain.setDouble(2, totalHarga);
            pstmtMain.setTimestamp(3, Timestamp.valueOf(trx.getTimestamp()));
            pstmtMain.executeUpdate();

            // Ambil ID transaksi yang baru dibuat
            ResultSet generatedKeys = pstmtMain.getGeneratedKeys();
            int idTransaksi = -1;
            if (generatedKeys.next()) {
                idTransaksi = generatedKeys.getInt(1);
            }

            if (idTransaksi == -1) {
                throw new SQLException("Gagal mendapatkan ID transaksi utama.");
            }

            // Hitung jumlah masing-masing item
            Map<String, Integer> itemCounts = new LinkedHashMap<>();
            Map<String, Double> itemPrices = new LinkedHashMap<>();

            for (MenuProduct item : trx.getItems()) {
                String name = item.getName();
                itemCounts.put(name, itemCounts.getOrDefault(name, 0) + 1);
                itemPrices.put(name, item.getPrice());
            }

            // Step 2: Insert ke transaksi_detail
            for (Map.Entry<String, Integer> entry : itemCounts.entrySet()) {
                String itemName = entry.getKey();
                int qty = entry.getValue();
                double price = itemPrices.get(itemName);
                double total = qty * price;

                pstmtDetail.setInt(1, idTransaksi);
                pstmtDetail.setString(2, itemName);
                pstmtDetail.setInt(3, qty);
                pstmtDetail.setDouble(4, price);
                pstmtDetail.setDouble(5, total);

                pstmtDetail.addBatch();
            }

            pstmtDetail.executeBatch();

            conn.commit(); // commit semua perubahan
            System.out.println("Data transaksi berhasil disimpan ke transaksi_utama dan transaksi_detail!");
        } catch (SQLException e) {
            conn.rollback(); // kalau error, rollback semua
            throw e;
        }
    } catch (SQLException ex) {
        System.err.println("Gagal menyimpan transaksi: " + ex.getMessage());
        ex.printStackTrace();
    }
}

}
