package controller;

import model.Transaction;
import java.util.ArrayList;
import java.util.List;

public class TransactionController {
    private List<Transaction> transactions = new ArrayList<>();

    public void addTransaction(Transaction t) {
        transactions.add(t);
    }

    public List<Transaction> getTodayTransactions() {
        return transactions;
    }
}
