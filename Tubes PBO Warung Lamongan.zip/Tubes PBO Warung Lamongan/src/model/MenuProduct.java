package model;

import java.util.ArrayList;
import java.util.List;

public class MenuProduct {
    private String name;
    private String category;
    private double price;

    public MenuProduct(String name, String category, double price) {
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return name + " - Rp " + price;
    }

    public static List<MenuProduct> getAllProducts() {
        List<MenuProduct> products = new ArrayList<>();

        // Makanan
        products.add(new MenuProduct("Lele Goreng", "Makanan", 15000));
        products.add(new MenuProduct("Ayam Bakar", "Makanan", 18000));
        products.add(new MenuProduct("Ikan Nila Goreng", "Makanan", 17000));
        products.add(new MenuProduct("Ikan Nila Bakar", "Makanan", 19000));
        products.add(new MenuProduct("Tahu Tempe", "Makanan", 7000));
        products.add(new MenuProduct("Telor Goreng", "Makanan", 6000));
        products.add(new MenuProduct("Telor Bakar", "Makanan", 7000));
        products.add(new MenuProduct("Kol Goreng", "Makanan", 4000));
        products.add(new MenuProduct("Extra Kremesan", "Makanan", 2000));
        products.add(new MenuProduct("Nasi Putih", "Makanan", 4000));  
        products.add(new MenuProduct("Nasi Uduk", "Makanan", 6500));   

        // Minuman
        products.add(new MenuProduct("Le Minerale", "Minuman", 5000));
        products.add(new MenuProduct("Teh Botol", "Minuman", 6000));
        products.add(new MenuProduct("Es Jeruk", "Minuman", 7000));
        products.add(new MenuProduct("Es Teh", "Minuman", 4000));

        return products;
    }
}
