package model;

public class FoodItem extends MenuProduct {
    public FoodItem(String id, String name, int price) {
        super(id, name, price);
    }
}
