package model;

public class DrinkItem extends MenuProduct {
    public DrinkItem(String id, String name, int price) {
        super(id, name, price);
    }
}
