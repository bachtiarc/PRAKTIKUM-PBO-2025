package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Transaction {
    private List<MenuProduct> items;
    private LocalDateTime timestamp;

    // Constructor default
    public Transaction() {
        this.items = new ArrayList<>();
        this.timestamp = LocalDateTime.now();
    }

    // Constructor lengkap (sesuai error kamu)
    public Transaction(List<MenuProduct> items, LocalDateTime timestamp) {
        this.items = items;
        this.timestamp = timestamp;
    }

    public void addItem(MenuProduct item) {
        items.add(item);
    }

    public List<MenuProduct> getItems() {
        return items;
    }

    public void clearItems() {
        items.clear();
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public double calculateTotal() {
        double total = 0;
        for (MenuProduct item : items) {
            total += item.getPrice();
        }
        return total;
    }
}
